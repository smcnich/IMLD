File: nedc_eas/v5.1.2/AAREADME.txt
Tool: The NEDC EEG Annotation System
Version: 5.1.2

-------------------------------------------------------------------------------
Change Log:
(20230907) reworked path for window/unix and migrated to PyQT5. Remove the need
      	   for Anaconda.
(20220505) clarifications for Windows users
(20220430) incorporates our new annotation libraries
(20210826) fixed some bugs in reading cvs files; changed the name to EAS
(20210529) updated to Python 3.7.x improved portability
-------------------------------------------------------------------------------

This directory contains all the Python code needed to run our annotation
tool. This tool has been used to annotate various NEDC EEG corpora. To
learn more about the origins of the tool, please see this publication:

 Capp, N., Krome, E., Obeid, I., & Picone, J. (2017). Facilitating the
 Annotation of Seizure Events Through an Extensible Visualization
 Tool. In I. Obeid, I. Selesnick, & J. Picone (Eds.), Proceedings of
 the IEEE Signal Processing in Medicine and Biology Symposium
 (p. 1). IEEE. https://doi.org/10.1109/SPMB.2017.8257043

Please cite this publication when referring to this tool.

A. WHAT'S NEW

Version 5.1.1 changes:
  + Update the README file to clarify the installation for Window User
  + Small cosmetic changes 

B. INSTALLATION REQUIREMENTS

Python code unfortunately often depends on a large number of add-ons, making
it very challenging to port code into new environments. This tool has been
tested extensively on Windows and Mac machines running Python v3.9.x.

Software tools required include:

 o Python 3.7.x or higher (we recommend installing Anaconda)
 o PyQt5: https://www.riverbankcomputing.com/software/pyqt/download5
 o Numpy/SciPy: http://www.numpy.org/
 o PyQtGraph: http://www.pyqtgraph.org/ (v0.11.0)
 o ReportLab: http://www.reportlab.com/
 o lxml: https://lxml.de

There is a requirements.txt included in the release that helps you automate
the process of updating your environment.

C. USER'S GUIDE

C.1. WINDOW USERS

For Window users, we recommend users to create a virtual environment with venv.(https://docs.python.org/3/library/venv.html)

We can create a virtual environment with this command:

 $ python -m venv /path/to/new/virtual/environment

Once the environment has been created, you need to do the following things if
you want to run this from any directory:

 1./ Activate your venv environment

    If you are using cmd.exe: 
	$ <venv>\Scripts\activate.bat

    If you are using Powershell: 
	$ <venv>\Scripts\Activate.ps1

    If sucessful, you should be able to see your environment name in parenthesis at the beginning of the command then followed by your current
    directory:
	Ex: (nedc_eas_virtual_environment) PS C:\Users\foo\bar>

 2./ Installing dependencies
   
    Change directory to the root of nedc_eas(v5.1.2). You should see a requirement.txt file there.
    
    Once you are at the root of the system, please run this command to install all the needed dependencies:
     
    $ pip install -r requirements.txt

 3./ Running the main script

    At the root of the project. Please run the main.py script located in the src directory:

    $ python .\src\main.py

    NOTE: Please use a terminal that enables GUI rendering. Microsoft Terminal is recommended.  

C.2. LINUX/MAC USERS

For Mac users, since Mac OS X 10.8 comes with Python 2.7, you may 
need to utilize pip3 when attempting to install dependencies:

 $ pip3 install pyqt5
 $ pip3 install pyqtgraph==0.11.0
 $ pip3 install reportlab
 $ pip3 install lxml
 $ pip3 install scipy

The easiest way to run this is to change your current working directory
to the root directory of the installation and execute the tool as follows:
 $ cd <my_install_location>/nedc_eas/v5.1.1
 $ ./bin/nedc_eas
 
Once the software has been installed, you need to do the following things if
you want to run this from any directory:

 - set the environment variable NEDC_NFC to the root directory
   of the installation:
      $ export NEDC_NFC='<my_install_location>/nedc_eas/v5.1.1'

 - put $NEDC_NFC/bin in your path:
      $ export PATH=$PATH:$NEDC_NFC
 
You should be able to type:

 $ which nedc_eas

and see the command. Then you can simply type:

 $ nedc_eas

After loading the tool, click on open under file on the navigation bar and
load the edf file that you wish to annotate.

A short tutorial on how to use the tool is available here:

https://www.isip.piconepress.com/projects/tuh_eeg/downloads/nedc_eas/v5.0.5/videos/getting_started/getting_started_v00.mp4

-----------------------------

If you have any additional comments or questions about the data,
please direct them to help@nedcdata.org.

Best regards,

Joe Picone
