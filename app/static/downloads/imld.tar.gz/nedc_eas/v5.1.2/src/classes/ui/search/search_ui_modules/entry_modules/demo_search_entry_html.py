

HTML_HEAD = \
"<head>"                            \
  "<meta name    = \"qrichtext\""   \
        "content = \"1\" />"        \
  "<style "                         \
    "type = \"text/css\">"          \
      "p, li                        \
        { white-space: pre-wrap; }" \
  "</style>"                        \
"</head>"





EDF_NAME_FONT =                     \
"style=\""                          \
  "font-size   : 14pt;"             \
  "font-weight : 600;"              \
  "color       : #07137c;"          \
"\">"





EXTRACT_TEXT_STYLE =                \
"style=\""                          \
  "font-size        : 11pt;"        \
  "margin-top       : 0px;"         \
  "margin-bottom    : 0px;"         \
  "margin-left      : 0px;"         \
  "margin-right     : 0px; "        \
  "-qt-block-indent : 0; "          \
  "text-indent      : 0px;"         \
"\">"
